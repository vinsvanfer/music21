#!/usr/bin/python

"""
Files in this package relate to aiding in composition -- 
this package might not be in the music21 distribution
and should be removed by then, but they're helpful for 
CuthbertLab
"""